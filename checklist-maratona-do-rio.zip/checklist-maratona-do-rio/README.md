# Checklist Maratona do Rio

A Pen created on CodePen.io. Original URL: [https://codepen.io/oagra/pen/RwmovLO](https://codepen.io/oagra/pen/RwmovLO).

